
function MyAbout(){
    return(
        <div>
            <h1>ABOUT</h1>
        </div>
    );
}
export default MyAbout;