import './App.css';


function MyNav(){
    return(
        <div>
            <ul>
                <li>HOME</li>
                <li>ABOUT</li>
                <li>CONTACT</li>
            </ul>
        </div>
    );
}
export default MyNav;