
function MyHome(){
    return(
        <div className='home'>
            <h1>HEADING</h1>
        </div>
    );
}
export default MyHome;