import React from 'react';

import './App.css';

import MyHome from './component/MyHome';
import MyAbout from './MyAbout';

import {BrowserRouter as Router,Route,Link,Switch } from 'react-router-dom';

function App() {
  return (
    <Router>
   
    <div>
      
        <nav>
          <ul className='nav-links'>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/About">About</Link>
            </li>
           
          </ul>
        </nav>
        
      <Switch> 
     <Route exact path="/" component={MyHome} />
     <Route path="/About" component={MyAbout} />
     
     </Switch>
     
    </div>
    </Router>
  );
}

export default App;

